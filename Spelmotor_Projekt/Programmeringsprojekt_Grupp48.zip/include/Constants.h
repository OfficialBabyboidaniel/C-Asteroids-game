#ifndef CONSTANTS_H
#define CONSTANTS_H

#include <string>

namespace constants
{
    //gResPath-contains the relative path to your resources.
	const std::string gResPath = "./resources/";
}

#endif