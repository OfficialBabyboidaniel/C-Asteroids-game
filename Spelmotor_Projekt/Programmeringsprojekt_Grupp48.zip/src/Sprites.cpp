#include "Sprites.h"
namespace cwing
{

    Sprites::Sprites(int x, int y, int w, int h) : rect{x, y, w, h}
    {
    }

    Sprites::~Sprites()
    {
    }

}